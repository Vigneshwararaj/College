main=do
 putStrLn("Enter the length of sides of traingle\nSide1:")
 num <- getLine
 let a= read num::Int
 putStrLn("Side2:")
 num <-getLine
 let b= read num::Int
 putStrLn("Side3:")
 num <-getLine
 let c= read num::Int
 if a==b && b==c 
      then putStrLn("Equilateral triangle") 
   else if a==b || b==c ||a==c 
      then putStrLn("Isosceles triangle")
   else putStrLn("Scalene tringle")