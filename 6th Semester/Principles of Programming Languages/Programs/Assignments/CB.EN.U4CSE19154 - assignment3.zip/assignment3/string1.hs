main = do
 putStrLn("Enter your address : ")
 a <- getLine
 putStrLn("Your address is")
 putStrLn(a)