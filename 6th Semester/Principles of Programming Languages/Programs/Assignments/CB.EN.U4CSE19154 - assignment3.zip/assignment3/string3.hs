countv::[Char]->(Int, Int)
countv txt = countc txt 0 0

countc::[Char]->Int->Int->(Int, Int)
countc [] con vow = (con, vow)
countc (c:r) con vow
    |c=='a' || c=='e' || c=='i' || c=='o' || c=='u' = countc r con (vow + 1)
    |otherwise = countc r (con + 1) vow

main = do
 putStrLn("Enter the text :")
 str <- getLine
 print(countv(str))