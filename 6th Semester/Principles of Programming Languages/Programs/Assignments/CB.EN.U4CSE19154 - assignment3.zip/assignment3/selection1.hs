main=do
 putStrLn ("Enter the Fahrenheit temperature : ")
 tem <- getLine
 let a = (read tem)
 if a >= 80 then putStrLn("Go play golf") 
 else if a >= 70 && a <= 79
 then putStrLn("Put on a jacket") 
 else putStrLn("It is way too cold") 