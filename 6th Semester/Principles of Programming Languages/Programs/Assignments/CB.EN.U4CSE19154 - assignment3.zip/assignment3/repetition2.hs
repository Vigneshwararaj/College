palindrome a = do
 let b = reverse a
 if b == a then putStrLn("The given number is palindrome") 
 else putStrLn("The given number is not a palindrome")
main=do
 putStrLn("Enter the number:")
 a <- getLine
 palindrome a