main = do
 putStrLn("Enter your name :")
 name <- getLine
 putStrLn("Enter your Age : ")
 age <- getLine
 let a = (read age)
 let b = 16 - a
 if a >= 16 then putStrLn("You are old enough to drive.") 
 else putStrLn("You have to wait for "++ show (b)++" years.")