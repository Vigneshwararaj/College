palindrome a = do
 let b = reverse a
 if b == a then putStrLn("The given word is palindrome") 
 else putStrLn("The given word is not a palindrome")
main=do
 putStrLn("Enter the word :")
 a <- getLine
 palindrome a