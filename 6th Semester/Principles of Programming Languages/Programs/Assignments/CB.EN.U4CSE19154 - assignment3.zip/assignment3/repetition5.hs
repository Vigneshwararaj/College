odds a =[x | x <- [1..a], odd x]
rsum a = sum (odds a)

main=do
 putStrLn("Enter a limit :")
 num <- getLine
 let a = read num
 putStrLn("The sum of odd numbers upto "++show(a)++" is " ) 
 print(rsum a)