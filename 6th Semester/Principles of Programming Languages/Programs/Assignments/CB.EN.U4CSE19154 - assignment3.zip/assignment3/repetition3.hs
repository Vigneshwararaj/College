digit :: Int -> [Int]
digit = map (read . (:[])) . show
listsum:: [Int] -> Int
listsum a = do
    let b = head a
    let c = tail a
    if null c
    then b*b*b
    else
        b*b*b + listsum c
        
main=do
    putStrLn("Enter the number:")
    a<-getLine
    let x = read a::Int
    let l= digit x
    if listsum l == x
    then putStrLn("The given number is armstrong number")
    else putStrLn("The given number is not a armstrong number")