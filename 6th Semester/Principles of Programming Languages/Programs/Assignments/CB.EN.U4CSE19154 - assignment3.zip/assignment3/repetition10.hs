summ::[Int]->Int
summ []=0
summ (x:xs)=x + summ xs
main =do
    putStrLn("The Sum of integer between 100 and 200 that are divisible by 9 is ")
    print(summ [x|x<-[100..200],mod x 9 ==0])