conv a=do
    let year=div a 365
    let week=div (mod a 365) 7
    let day=mod (mod a 365) 7
    putStrLn ("Years :" ++ show (year) ++"\nweeks: "++show(week)++"\nDays: "++show(day))

main = do
 putStrLn ("Enter the number of days : ")
 num <- getLine
 let a = (read num) :: Int
 conv(a)