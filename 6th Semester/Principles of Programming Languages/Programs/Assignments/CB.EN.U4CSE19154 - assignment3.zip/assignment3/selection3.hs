main = do
 putStrLn ("Enter the  hourly pay rate: ")
 inp <- getLine
 putStrLn ("Enter the number of hours worked for the week: ")
 inp <-getLine
 let a = (read inp) :: Float
 let b = (read inp) :: Float
 let c = (40*a)+((b-40)*1.5*a)
 let d = (40*a)
 if a >= 40 then putStrLn ("The weekly pay is " ++ show (c)) 
 else putStrLn ("The weekly pay is " ++ show (d))