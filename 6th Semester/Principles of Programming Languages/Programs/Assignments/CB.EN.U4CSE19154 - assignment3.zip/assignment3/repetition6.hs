dig :: Int -> [Int]
dig = map (read . (:[])) . show

dec::[Int]->Int->Int
dec l n = do
    let bit = head l
    let rest = tail l
    if n==0                                                                                                                                                             
    then bit
    else do
        let nn=n-1
        ((2^n)*bit )+ dec rest nn
        
main=do
 putStrLn ("Enter the number in binary:")
 a<-getLine
 let x=read a::Int
 let l= dig x
 let len=((length l) - 1)
 putStrLn ("The Decimal is "++show(dec l len))