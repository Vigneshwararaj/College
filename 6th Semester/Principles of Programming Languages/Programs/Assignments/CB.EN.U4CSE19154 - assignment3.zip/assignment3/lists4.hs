pro :: ([Int]) -> Int
pro (a) = do
 if a /= [] then 
  head a*pro(drop 1 a)
 else 1

main = do
 putStrLn("Enter the list of numbers:")
 num <- getLine
 let a = read num :: [Int]
 putStrLn("The product of numbers is ")
 print(pro a)