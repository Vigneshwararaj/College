primecheck::Int->Int->Bool
primecheck x n = do
    if x==1
    then True
    else if mod n x == 0 
        then False
    else do
        let c=x-1
        primecheck c n

main=do
    putStrLn("Enter the first number :")
    a<-getLine
    putStrLn("Enter the second number :")
    b<-getLine
    let n = read a::Int 
    let m = read b::Int
    print([x|x<-[n..m],primecheck (x-1) x])