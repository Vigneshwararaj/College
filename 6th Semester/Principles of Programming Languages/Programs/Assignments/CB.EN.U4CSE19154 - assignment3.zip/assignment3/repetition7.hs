covert::Int->String
fun::Int->String
fun a=do
    if mod a 2 ==1 then "1" else "0"
covert 0 = ""
covert a = fun a ++ covert (div a 2)

main =do
    putStrLn("Enter the decimal number:")
    x<-getLine
    let a=read x::Int
    putStrLn("The binary is")
    print(reverse (covert a))