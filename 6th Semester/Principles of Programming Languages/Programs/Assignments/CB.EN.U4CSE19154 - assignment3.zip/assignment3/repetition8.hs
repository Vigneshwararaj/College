fun::Char->String
fun '0'=" Zero "
fun '1'=" One "
fun '2'=" Two "
fun '3'=" Three "
fun '4'=" Four "
fun '5'=" Five "
fun '6'=" Six "
fun '7'=" Seven "
fun '8'=" Eight "
fun '9'=" Nine "
function::String->String
function "" = ""
function (x:xs)=fun x ++ function xs

main =do
    putStrLn("Enter the number to convert into words :")
    x<-getLine
    print(function x)