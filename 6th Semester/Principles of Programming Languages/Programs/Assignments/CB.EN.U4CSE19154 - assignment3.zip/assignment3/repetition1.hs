prime :: (Int,Int) -> Int
prime (a,1) = 1
prime (a,n) = (rem a n)* (prime(a ,n-1))

main = do
    putStrLn("Enter the number:")
    num <- getLine
    let n = read num :: Int
    if (prime(n,n-1) /= 0) 
        then putStrLn("The given number is prime")
    else
        putStrLn("The given number is not a prime")