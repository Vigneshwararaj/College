evens a =[x | x <- [1..a], even x]
rsum a = sum (evens a)

main=do
 putStrLn("Enter a limit :")
 num <- getLine
 let a = read num
 putStrLn("The sum of even numbers upto "++show(a)++" is " ) 
 print(rsum a)