conv a = do
    let b = ((mod a 10)*10)+(div a 10)
    let c = abs (a-b)
    putStrLn ("Reverse is :" ++ show (b)++"\nDifference is :" ++ show (c))
    
main = do
 putStrLn ("Enter the two digit number : ")
 num <- getLine
 let a = (read num)
 conv(a)